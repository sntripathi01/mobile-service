package com.redox.notification.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Logger;

public class MobileServiceUtil {
	private static Logger LOG = Logger.getLogger(MobileServiceUtil.class.getName());

	public static String getSchoolId() {

		InputStream is = null;
		String schoolId = null;
		try {
			Properties prop = new Properties();
			is = MobileServiceUtil.class.getClass().getResourceAsStream("/mobile-service.properties");
			prop.load(is);
			schoolId = prop.getProperty("schoolId");
		} catch (FileNotFoundException e) {
			LOG.info("MobileServiceUtil  : getSchoolId FileNotFoundException " + e);

		} catch (IOException e) {
			LOG.info("MobileServiceUtil  : getSchoolId IOException " + e);

		}catch(Exception e){
			LOG.info("MobileServiceUtil  : getSchoolId excetion " + e);	
		}
		LOG.info("MobileServiceUtil  : getSchoolId Exception " + schoolId);
		return schoolId;
	}

}
