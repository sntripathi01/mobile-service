package com.redox.mobile.service.model;

import java.util.Map;

public class NotificationRequest {
	public void aa() {
		Map<String, Float> feeComponent = null;

		for (Map.Entry<String, Float> entry : feeComponent.entrySet()) {
			System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
		}
	}

}
